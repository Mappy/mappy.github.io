#!/usr/bin/python
####
#### Licensed to the Apache Software Foundation (ASF) http://www.apache.org/licenses/LICENSE-2.0
#### See http://www.mappy.com for instructions
####

import os
import sys
import argparse
import subprocess
import SimpleHTTPServer
import SocketServer

def run_http_server(port):
    Handler = SimpleHTTPServer.SimpleHTTPRequestHandler
    httpd = SocketServer.TCPServer(("", port), Handler)
    print "serving at port", port
    httpd.serve_forever()

def main():
    print "Running Solr AutoComplete example in Jetty."

    parser = argparse.ArgumentParser(description='Running Solr AutoComplete example in Jetty.\n')
    parser.add_argument('--jetty_home', required=True, help='your Solr example directory. Example: /home/ME/solr-4.6.0/solr/example')
    parser.add_argument('--solr_port', type=int, help='an integer for the accumulator', default=8983)
    parser.add_argument('--web_port', type=int, help='an integer for the accumulator', default=8000)
    args = parser.parse_args()

    SOLR_HOME = os.path.join(os.getcwd(), 'solr-home')

    JAVA_OPTIONS =  ["java",
                     "-server",
                     "-XX:+UseConcMarkSweepGC",
                     "-XX:+CMSClassUnloadingEnabled",
                     "-XX:-CMSParallelRemarkEnabled",
                     "-XX:+UseCMSCompactAtFullCollection",
                     "-XX:+UseParNewGC",
                     "-XX:+PrintGCDetails",
                     "-Xms512m", "-Xmx1024m",
                     "-Dsolr.solr.home={SOLR_HOME}".format(SOLR_HOME=SOLR_HOME),
                     "-Djetty.port={PORT}".format(PORT=args.solr_port),
                     "{JAVA_OPTIONS}".format(JAVA_OPTIONS=os.getenv("JAVA_OPTIONS") or ""),
                     "-jar", "./start.jar"]

    JAVA_OPTIONS = [option for option in JAVA_OPTIONS if option]

    print 'Solr command line:\n{}'.format(" ".join(JAVA_OPTIONS))

    solr_process = subprocess.Popen(JAVA_OPTIONS, cwd=args.jetty_home)

    try:
        run_http_server(args.web_port)
    finally:
        solr_process.terminate()

if __name__ == '__main__':
    main()