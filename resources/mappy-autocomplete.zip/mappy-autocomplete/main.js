$.extend( $.ui.autocomplete.prototype, {
    _renderItem: function( ul, item ) {
        var term = this.element.val(),
            html = item.label.replace( term, "<b>$&</b>" );
        return $( "<li></li>" )
            .data( "item.autocomplete", item )
            .append( $("<a></a>").html(html) )
            .appendTo( ul );
    }
});

$( "#tags" ).autocomplete({
      source: function( request, response ) {
        $.ajax({
          'url': 'http://localhost:8983/solr/acgeo/select?',
          'delay': 1,
          'dataType': "jsonp",
          'data': {
            'q': request.term,
            "wt": "json",
            "json.wrf" : "callback",
            "rows": 5,
            "lat_min":$("#south").val(),
            "lat_max":$("#north").val(),
            "lng_min":$("#west").val(),
            "lng_max":$("#east").val()
          },
          jsonpCallback: 'callback',
          success: function( data ) {
            var suggestList = [];
            console.log(data.response.docs.length)
            for(i=0; i<data.response.docs.length; i++) {
              suggestList.push({label : data.response.docs[i].name})
              //with a map api we could put some markers
            }
          response(suggestList);
          }
        });
      },
      minLength: 0
    });
