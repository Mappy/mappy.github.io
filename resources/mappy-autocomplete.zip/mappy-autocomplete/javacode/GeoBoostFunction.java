package com.mappy.lbs.solr.search.function;


/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.apache.lucene.index.AtomicReaderContext;
import org.apache.lucene.queries.function.FunctionValues;
import org.apache.lucene.queries.function.ValueSource;
import org.apache.lucene.queries.function.docvalues.FloatDocValues;
import org.apache.lucene.search.IndexSearcher;

import java.io.IOException;
import java.util.Map;

import java.lang.Math.*;


/**
 * Calculate the p-norm for a Vector.  See http://en.wikipedia.org/wiki/Lp_space
 * <p/>
 * Common cases:
 * <ul>
 * <li>0 = Sparseness calculation</li>
 * <li>1 = Manhattan distance</li>
 * <li>2 = Euclidean distance</li>
 * <li>Integer.MAX_VALUE = infinite norm</li>
 * </ul>
 *
 * @see SquaredEuclideanFunction for the special case
 */
public class GeoBoostFunction extends ValueSource {
  protected ValueSource lat, lng;
  protected float latmin, lngmin, latmax, lngmax;
  protected float eps, mu;

  public GeoBoostFunction(float eps, float mu, float latmin, float lngmin, float latmax, float lngmax, ValueSource lat, ValueSource lng) {
	
	this.lat = lat;
	this.lng = lng;
	this.eps = eps;
	this.mu = mu;
	this.latmin = latmin;
	this.lngmin = lngmin;
	this.latmax = latmax;
	this.lngmax = lngmax;

  }

  protected String name() {
    return "geoboost";
  }

  protected float diffangle( float a, float b ) {
  	float d1 = Math.abs( a - b );
  	if (d1 >= 180) {
  		d1 = 360 - d1;
  	}
  	return d1;
  }
  
  /**
   * Calculate the distance
   *
   * @param doc The current doc
   * @param dv The values from the MultiValueSource
   * @return The boost value
   */
  protected float boost(int doc, FunctionValues latvals, FunctionValues lngvals ) {
    //Handle some special cases:
    float latv = latvals.floatVal(doc);
    float lngv = lngvals.floatVal(doc);
  
    float score_lat = 1;
    float score_lng = 1;
    
    if (latv < latmin) {
    	float L = latmax - latmin;
    	score_lat =  L / (mu*( latmin - latv) + L);
    } else if(latv > latmax) {
    	float L = latmax - latmin;
    	score_lat =  L / (mu*( latv - latmax) + L);
    } 
   
    if (lngmin < lngmax) {
    	if (lngv < lngmin || lngv > lngmax) {
    		float d = Math.min( diffangle( lngv , lngmin) , diffangle( lngv , lngmax) );
        	float L = lngmax - lngmin;
        	score_lng = L / (mu*d + L);
    	}	
    } else {
    	if (lngv > lngmin || lngv < lngmax) {
    		float d = Math.min( diffangle( lngv , lngmin) , diffangle( lngv , lngmax) );
        	float L = diffangle( lngmax, lngmin );
        	score_lng = L / (mu*d + L);
    	}	    	
    }
    
    return (eps + score_lat * score_lng * (1 - eps));
  }

  @Override
  public FunctionValues getValues(Map context, AtomicReaderContext readerContext) throws IOException {

    final FunctionValues latvals = lat.getValues(context, readerContext);
    final FunctionValues lngvals = lng.getValues(context, readerContext);

    return new FloatDocValues(this) {

      @Override
      public float floatVal(int doc) {
        return boost(doc, latvals, lngvals);
      }

      @Override
      public String toString(int doc) {
        StringBuilder sb = new StringBuilder();
        sb.append(name()).append('(');
        sb.append(Float.toString(eps)).append(',');
        sb.append(Float.toString(mu)).append(',');
        sb.append(Float.toString(latmin)).append(',');
        sb.append(Float.toString(lngmin)).append(',');
        sb.append(Float.toString(latmax)).append(',');
        sb.append(Float.toString(lngmax)).append(',');
        sb.append(latvals.toString(doc)).append(',');
        sb.append(lngvals.toString(doc));
        sb.append(')');
        return sb.toString();
      }

    };
  }

  @Override
  public void createWeight(Map context, IndexSearcher searcher) throws IOException {
    lat.createWeight(context, searcher);
    lng.createWeight(context, searcher);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof GeoBoostFunction)) return false;

    GeoBoostFunction that = (GeoBoostFunction) o;

    if (Float.compare(that.eps, eps) != 0) return false;
    if (Float.compare(that.mu, mu) != 0) return false;
    if (Float.compare(that.latmin, latmin) != 0) return false;
    if (Float.compare(that.lngmin, lngmin) != 0) return false;
    if (Float.compare(that.latmax, latmax) != 0) return false;
    if (Float.compare(that.lngmax, lngmax) != 0) return false;
    if (!lat.equals(that.lat)) return false;
    if (!lng.equals(that.lng)) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = lat.hashCode() + lng.hashCode();
    result = 31 * result + Float.floatToRawIntBits(eps) ;
    result = 31 * result + Float.floatToRawIntBits(mu) ;
    result = 31 * result + Float.floatToRawIntBits(latmin);
    result = 31 * result + Float.floatToRawIntBits(lngmin);
    result = 31 * result + Float.floatToRawIntBits(latmax);
    result = 31 * result + Float.floatToRawIntBits(lngmax);
    	
    return result;
  }

  @Override
  public String description() {
      StringBuilder sb = new StringBuilder();
      sb.append(name()).append('(');
      sb.append(Float.toString(eps)).append(',');
      sb.append(Float.toString(mu)).append(',');
      sb.append(Float.toString(latmin)).append(',');
      sb.append(Float.toString(lngmin)).append(',');
      sb.append(Float.toString(latmax)).append(',');
      sb.append(Float.toString(lngmax)).append(',');
      sb.append(lat.description()).append(',');
      sb.append(lng.description());
      sb.append(')');
      return sb.toString();
  }

}
