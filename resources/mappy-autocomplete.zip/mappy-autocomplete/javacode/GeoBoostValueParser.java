package com.mappy.lbs.solr.search.function;

import org.apache.lucene.queries.function.ValueSource;
import org.apache.solr.search.FunctionQParser;
import org.apache.solr.search.SyntaxError;
import org.apache.solr.search.ValueSourceParser;

import com.mappy.lbs.solr.search.function.GeoBoostFunction; 

public class GeoBoostValueParser extends ValueSourceParser {

    @Override
    public ValueSource parse(FunctionQParser fp) throws SyntaxError {
        float eps = fp.parseFloat();
        float mu = fp.parseFloat();
        float latmin = fp.parseFloat();
        float lngmin = fp.parseFloat();
        float latmax = fp.parseFloat();
        float lngmax = fp.parseFloat();
    	ValueSource lat = fp.parseValueSource();
    	ValueSource lng = fp.parseValueSource();
    	return new GeoBoostFunction(eps,mu,latmin,lngmin,latmax,lngmax,lat,lng);
    }
}
